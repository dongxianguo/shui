/********************************************************************************
** Form generated from reading UI file 'dig_login.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIG_LOGIN_H
#define UI_DIG_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dig_login
{
public:
    QGridLayout *gridLayout;
    QWidget *bg;
    QGridLayout *gridLayout_3;
    QLabel *lb_title;
    QLabel *lb_txt1;
    QLineEdit *line_user;
    QLabel *lb_txt2;
    QLineEdit *line_password;
    QWidget *widget_2;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *Dig_login)
    {
        if (Dig_login->objectName().isEmpty())
            Dig_login->setObjectName(QString::fromUtf8("Dig_login"));
        Dig_login->resize(772, 547);
        Dig_login->setStyleSheet(QString::fromUtf8("QLabel#lb_title{font: 38px \"\351\273\221\344\275\223\";}\n"
"QLabel#lb_txt1,QLabel#lb_txt2{font: 18px \"\346\245\267\344\275\223\";}\n"
"QLineEdit{border-radius:4px;min-height:25px;border:1px solid gray;}\n"
"QPushButton{border-radius:4px;background:#409eff;color:white;font-size:14px;}\n"
"QWidget#bg{background:white;}"));
        gridLayout = new QGridLayout(Dig_login);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        bg = new QWidget(Dig_login);
        bg->setObjectName(QString::fromUtf8("bg"));
        gridLayout_3 = new QGridLayout(bg);
        gridLayout_3->setSpacing(0);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        lb_title = new QLabel(bg);
        lb_title->setObjectName(QString::fromUtf8("lb_title"));
        lb_title->setMaximumSize(QSize(16777215, 50));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        lb_title->setFont(font);
        lb_title->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(lb_title, 0, 0, 1, 2);

        lb_txt1 = new QLabel(bg);
        lb_txt1->setObjectName(QString::fromUtf8("lb_txt1"));
        lb_txt1->setMaximumSize(QSize(100, 30));
        lb_txt1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_3->addWidget(lb_txt1, 1, 0, 1, 1);

        line_user = new QLineEdit(bg);
        line_user->setObjectName(QString::fromUtf8("line_user"));
        line_user->setMaximumSize(QSize(250, 30));

        gridLayout_3->addWidget(line_user, 1, 1, 1, 1);

        lb_txt2 = new QLabel(bg);
        lb_txt2->setObjectName(QString::fromUtf8("lb_txt2"));
        lb_txt2->setMaximumSize(QSize(100, 30));
        lb_txt2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_3->addWidget(lb_txt2, 2, 0, 1, 1);

        line_password = new QLineEdit(bg);
        line_password->setObjectName(QString::fromUtf8("line_password"));
        line_password->setMaximumSize(QSize(250, 30));

        gridLayout_3->addWidget(line_password, 2, 1, 1, 1);

        widget_2 = new QWidget(bg);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setMaximumSize(QSize(16777215, 70));
        gridLayout_2 = new QGridLayout(widget_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setHorizontalSpacing(50);
        gridLayout_2->setVerticalSpacing(0);
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMaximumSize(QSize(150, 40));

        gridLayout_2->addWidget(pushButton, 0, 0, 1, 1);

        pushButton_2 = new QPushButton(widget_2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMaximumSize(QSize(150, 50));

        gridLayout_2->addWidget(pushButton_2, 0, 1, 1, 1);


        gridLayout_3->addWidget(widget_2, 3, 0, 1, 2);


        gridLayout->addWidget(bg, 0, 0, 1, 1);


        retranslateUi(Dig_login);

        QMetaObject::connectSlotsByName(Dig_login);
    } // setupUi

    void retranslateUi(QDialog *Dig_login)
    {
        Dig_login->setWindowTitle(QCoreApplication::translate("Dig_login", "Dialog", nullptr));
        lb_title->setText(QCoreApplication::translate("Dig_login", "\345\233\276\344\271\246\351\246\206\347\256\241\347\220\206\347\263\273\347\273\237", nullptr));
        lb_txt1->setText(QCoreApplication::translate("Dig_login", "\347\224\250\346\210\267\345\220\215:", nullptr));
        lb_txt2->setText(QCoreApplication::translate("Dig_login", "\345\257\206\347\240\201:", nullptr));
        pushButton->setText(QCoreApplication::translate("Dig_login", "\347\231\273\345\275\225", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Dig_login", "\346\263\250\345\206\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dig_login: public Ui_Dig_login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIG_LOGIN_H
