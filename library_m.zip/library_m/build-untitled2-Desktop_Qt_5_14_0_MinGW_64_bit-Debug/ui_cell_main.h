/********************************************************************************
** Form generated from reading UI file 'cell_main.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CELL_MAIN_H
#define UI_CELL_MAIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_cell_main
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_2;
    QWidget *tool;
    QGridLayout *gridLayout;
    QPushButton *btn_user;
    QSpacerItem *verticalSpacer;
    QPushButton *btn_book;
    QPushButton *btn_brower;
    QPushButton *btn_count;
    QStackedWidget *stackedWidget;
    QButtonGroup *buttonGroup;

    void setupUi(QMainWindow *cell_main)
    {
        if (cell_main->objectName().isEmpty())
            cell_main->setObjectName(QString::fromUtf8("cell_main"));
        cell_main->resize(800, 600);
        centralwidget = new QWidget(cell_main);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("QWidget#toolQPushButton{border:none;background-color:rgb(84, 92, 100);} \n"
""));
        gridLayout_2 = new QGridLayout(centralwidget);
        gridLayout_2->setSpacing(0);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        tool = new QWidget(centralwidget);
        tool->setObjectName(QString::fromUtf8("tool"));
        tool->setStyleSheet(QString::fromUtf8("QWidget#tool QPushButton{border:none;background-color:rgb(84, 92, 100);color:white;min-height:60px;font: 14px \"\351\273\221\344\275\223\";padding-left:12px;padding-right:12px;}\n"
"QWidget#tool{background-color:rgb(82, 94, 100);}\n"
""));
        gridLayout = new QGridLayout(tool);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        btn_user = new QPushButton(tool);
        buttonGroup = new QButtonGroup(cell_main);
        buttonGroup->setObjectName(QString::fromUtf8("buttonGroup"));
        buttonGroup->addButton(btn_user);
        btn_user->setObjectName(QString::fromUtf8("btn_user"));

        gridLayout->addWidget(btn_user, 1, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 5, 0, 1, 1);

        btn_book = new QPushButton(tool);
        buttonGroup->addButton(btn_book);
        btn_book->setObjectName(QString::fromUtf8("btn_book"));

        gridLayout->addWidget(btn_book, 0, 0, 1, 1);

        btn_brower = new QPushButton(tool);
        buttonGroup->addButton(btn_brower);
        btn_brower->setObjectName(QString::fromUtf8("btn_brower"));

        gridLayout->addWidget(btn_brower, 2, 0, 1, 1);

        btn_count = new QPushButton(tool);
        buttonGroup->addButton(btn_count);
        btn_count->setObjectName(QString::fromUtf8("btn_count"));

        gridLayout->addWidget(btn_count, 3, 0, 1, 1);


        gridLayout_2->addWidget(tool, 0, 0, 1, 1);

        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));

        gridLayout_2->addWidget(stackedWidget, 0, 1, 1, 1);

        cell_main->setCentralWidget(centralwidget);

        retranslateUi(cell_main);

        stackedWidget->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(cell_main);
    } // setupUi

    void retranslateUi(QMainWindow *cell_main)
    {
        cell_main->setWindowTitle(QCoreApplication::translate("cell_main", "cell_main", nullptr));
        btn_user->setText(QCoreApplication::translate("cell_main", "\347\224\250\346\210\267\347\256\241\347\220\206", nullptr));
        btn_book->setText(QCoreApplication::translate("cell_main", "\345\233\276\344\271\246\347\256\241\347\220\206", nullptr));
        btn_brower->setText(QCoreApplication::translate("cell_main", "\345\200\237\351\230\205\347\256\241\347\220\206", nullptr));
        btn_count->setText(QCoreApplication::translate("cell_main", "\347\273\237\350\256\241\346\212\245\350\241\250", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cell_main: public Ui_cell_main {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CELL_MAIN_H
