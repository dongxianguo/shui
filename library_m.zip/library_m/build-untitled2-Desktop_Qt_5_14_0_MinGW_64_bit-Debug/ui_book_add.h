/********************************************************************************
** Form generated from reading UI file 'book_add.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BOOK_ADD_H
#define UI_BOOK_ADD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_book_login
{
public:
    QGridLayout *gridLayout;
    QWidget *widget;
    QGridLayout *gridLayout_2;
    QLabel *lg_txt5;
    QLineEdit *lg_is;
    QWidget *widget_2;
    QGridLayout *gridLayout_3;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLineEdit *lg_writer;
    QLineEdit *lg_time;
    QLabel *lg_txt4;
    QLabel *lg_txt2;
    QLabel *lg_txt1;
    QLineEdit *lg_bookname;
    QLabel *lg_txt3;
    QLabel *lg_txt6;
    QLineEdit *lg_class;
    QLineEdit *lg_press;

    void setupUi(QDialog *book_login)
    {
        if (book_login->objectName().isEmpty())
            book_login->setObjectName(QString::fromUtf8("book_login"));
        book_login->resize(801, 641);
        book_login->setStyleSheet(QString::fromUtf8("QLabel#lg_txt1,QLabel#lg_txt2,QLabel#lg_txt3,QLabel#lg_txt4,QLabel#lg_txt5,QLabel#lg_txt6{font: 18px \"\346\245\267\344\275\223\";}\n"
"QLineEdit{border-radius:4px;min-height:25px;border:1px solid gray;}\n"
"QPushButton{border-radius:4px;background:#409eff;color:white;font-size:14px;}\n"
"QDialog#book_login{background:white;}"));
        gridLayout = new QGridLayout(book_login);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        widget = new QWidget(book_login);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setMaximumSize(QSize(600, 500));
        gridLayout_2 = new QGridLayout(widget);
        gridLayout_2->setSpacing(0);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        lg_txt5 = new QLabel(widget);
        lg_txt5->setObjectName(QString::fromUtf8("lg_txt5"));
        lg_txt5->setMaximumSize(QSize(200, 30));
        lg_txt5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_2->addWidget(lg_txt5, 4, 0, 1, 1);

        lg_is = new QLineEdit(widget);
        lg_is->setObjectName(QString::fromUtf8("lg_is"));
        lg_is->setMaximumSize(QSize(300, 30));

        gridLayout_2->addWidget(lg_is, 3, 1, 1, 1);

        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setMaximumSize(QSize(600, 100));
        gridLayout_3 = new QGridLayout(widget_2);
        gridLayout_3->setSpacing(0);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(widget_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMaximumSize(QSize(200, 30));

        gridLayout_3->addWidget(pushButton, 0, 0, 1, 1);

        pushButton_2 = new QPushButton(widget_2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMaximumSize(QSize(200, 30));

        gridLayout_3->addWidget(pushButton_2, 0, 1, 1, 1);


        gridLayout_2->addWidget(widget_2, 6, 0, 1, 3);

        lg_writer = new QLineEdit(widget);
        lg_writer->setObjectName(QString::fromUtf8("lg_writer"));
        lg_writer->setMaximumSize(QSize(300, 30));

        gridLayout_2->addWidget(lg_writer, 1, 1, 1, 1);

        lg_time = new QLineEdit(widget);
        lg_time->setObjectName(QString::fromUtf8("lg_time"));
        lg_time->setMaximumSize(QSize(300, 30));

        gridLayout_2->addWidget(lg_time, 5, 1, 1, 1);

        lg_txt4 = new QLabel(widget);
        lg_txt4->setObjectName(QString::fromUtf8("lg_txt4"));
        lg_txt4->setMaximumSize(QSize(200, 30));
        lg_txt4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_2->addWidget(lg_txt4, 3, 0, 1, 1);

        lg_txt2 = new QLabel(widget);
        lg_txt2->setObjectName(QString::fromUtf8("lg_txt2"));
        lg_txt2->setMaximumSize(QSize(200, 30));
        lg_txt2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_2->addWidget(lg_txt2, 1, 0, 1, 1);

        lg_txt1 = new QLabel(widget);
        lg_txt1->setObjectName(QString::fromUtf8("lg_txt1"));
        lg_txt1->setMaximumSize(QSize(200, 30));
        lg_txt1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_2->addWidget(lg_txt1, 0, 0, 1, 1);

        lg_bookname = new QLineEdit(widget);
        lg_bookname->setObjectName(QString::fromUtf8("lg_bookname"));
        lg_bookname->setMaximumSize(QSize(300, 30));

        gridLayout_2->addWidget(lg_bookname, 0, 1, 1, 1);

        lg_txt3 = new QLabel(widget);
        lg_txt3->setObjectName(QString::fromUtf8("lg_txt3"));
        lg_txt3->setMaximumSize(QSize(200, 30));
        lg_txt3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_2->addWidget(lg_txt3, 2, 0, 1, 1);

        lg_txt6 = new QLabel(widget);
        lg_txt6->setObjectName(QString::fromUtf8("lg_txt6"));
        lg_txt6->setMaximumSize(QSize(200, 30));
        lg_txt6->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_2->addWidget(lg_txt6, 5, 0, 1, 1);

        lg_class = new QLineEdit(widget);
        lg_class->setObjectName(QString::fromUtf8("lg_class"));
        lg_class->setMaximumSize(QSize(300, 30));

        gridLayout_2->addWidget(lg_class, 4, 1, 1, 1);

        lg_press = new QLineEdit(widget);
        lg_press->setObjectName(QString::fromUtf8("lg_press"));
        lg_press->setMaximumSize(QSize(300, 30));

        gridLayout_2->addWidget(lg_press, 2, 1, 1, 1);


        gridLayout->addWidget(widget, 0, 0, 1, 1);


        retranslateUi(book_login);

        QMetaObject::connectSlotsByName(book_login);
    } // setupUi

    void retranslateUi(QDialog *book_login)
    {
        book_login->setWindowTitle(QCoreApplication::translate("book_login", "Dialog", nullptr));
        lg_txt5->setText(QCoreApplication::translate("book_login", "\347\261\273\345\210\253\357\274\232 ", nullptr));
        pushButton->setText(QCoreApplication::translate("book_login", "\347\241\256\345\256\232", nullptr));
        pushButton_2->setText(QCoreApplication::translate("book_login", "\350\277\224\345\233\236", nullptr));
        lg_txt4->setText(QCoreApplication::translate("book_login", "ISBN\357\274\232 ", nullptr));
        lg_txt2->setText(QCoreApplication::translate("book_login", "\344\275\234\350\200\205\357\274\232 ", nullptr));
        lg_txt1->setText(QCoreApplication::translate("book_login", "\344\271\246\345\220\215\357\274\232 ", nullptr));
        lg_txt3->setText(QCoreApplication::translate("book_login", "\345\207\272\347\211\210\347\244\276\357\274\232 ", nullptr));
        lg_txt6->setText(QCoreApplication::translate("book_login", "\345\200\237\351\230\205\346\227\266\351\225\277\357\274\232 ", nullptr));
    } // retranslateUi

};

namespace Ui {
    class book_login: public Ui_book_login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BOOK_ADD_H
