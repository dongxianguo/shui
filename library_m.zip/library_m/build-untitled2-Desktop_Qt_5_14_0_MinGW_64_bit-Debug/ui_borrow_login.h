/********************************************************************************
** Form generated from reading UI file 'borrow_login.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BORROW_LOGIN_H
#define UI_BORROW_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_borrow_login
{
public:
    QGridLayout *gridLayout;
    QWidget *widget;
    QTableView *tableView;
    QWidget *widget_2;
    QGridLayout *gridLayout_2;
    QLineEdit *lineEdit;
    QLabel *label;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer;

    void setupUi(QDialog *borrow_login)
    {
        if (borrow_login->objectName().isEmpty())
            borrow_login->setObjectName(QString::fromUtf8("borrow_login"));
        borrow_login->resize(642, 501);
        gridLayout = new QGridLayout(borrow_login);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        widget = new QWidget(borrow_login);
        widget->setObjectName(QString::fromUtf8("widget"));
        tableView = new QTableView(widget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(10, 40, 521, 431));
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setGeometry(QRect(0, 0, 531, 51));
        gridLayout_2 = new QGridLayout(widget_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        lineEdit = new QLineEdit(widget_2);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        gridLayout_2->addWidget(lineEdit, 0, 1, 1, 1);

        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_2->addWidget(label, 0, 0, 1, 1);

        pushButton_2 = new QPushButton(widget_2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        gridLayout_2->addWidget(pushButton_2, 0, 3, 1, 1);

        pushButton = new QPushButton(widget_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout_2->addWidget(pushButton, 0, 2, 1, 1);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer, 0, 4, 1, 1);


        gridLayout->addWidget(widget, 0, 0, 1, 1);


        retranslateUi(borrow_login);

        QMetaObject::connectSlotsByName(borrow_login);
    } // setupUi

    void retranslateUi(QDialog *borrow_login)
    {
        borrow_login->setWindowTitle(QCoreApplication::translate("borrow_login", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("borrow_login", "\346\220\234\347\264\242", nullptr));
        pushButton_2->setText(QCoreApplication::translate("borrow_login", "\344\277\256\346\224\271\344\277\241\346\201\257", nullptr));
        pushButton->setText(QCoreApplication::translate("borrow_login", "\347\224\250\346\210\267\345\257\274\345\205\245", nullptr));
    } // retranslateUi

};

namespace Ui {
    class borrow_login: public Ui_borrow_login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BORROW_LOGIN_H
