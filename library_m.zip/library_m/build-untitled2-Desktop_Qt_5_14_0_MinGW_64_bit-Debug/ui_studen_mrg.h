/********************************************************************************
** Form generated from reading UI file 'studen_mrg.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STUDEN_MRG_H
#define UI_STUDEN_MRG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_borrow_login
{
public:
    QGridLayout *gridLayout_3;
    QWidget *widget;
    QGridLayout *gridLayout_2;
    QWidget *widget_2;
    QGridLayout *gridLayout;
    QLineEdit *lineEdit;
    QLabel *label;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QPushButton *pushButton_3;
    QTableWidget *tableWidget;

    void setupUi(QDialog *borrow_login)
    {
        if (borrow_login->objectName().isEmpty())
            borrow_login->setObjectName(QString::fromUtf8("borrow_login"));
        borrow_login->resize(671, 420);
        borrow_login->setMinimumSize(QSize(659, 420));
        gridLayout_3 = new QGridLayout(borrow_login);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        widget = new QWidget(borrow_login);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout_2 = new QGridLayout(widget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        gridLayout = new QGridLayout(widget_2);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        lineEdit = new QLineEdit(widget_2);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        gridLayout->addWidget(lineEdit, 0, 1, 1, 1);

        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(label, 0, 0, 1, 1);

        pushButton_2 = new QPushButton(widget_2);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        gridLayout->addWidget(pushButton_2, 0, 4, 1, 1);

        pushButton = new QPushButton(widget_2);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 0, 3, 1, 1);

        pushButton_3 = new QPushButton(widget_2);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        gridLayout->addWidget(pushButton_3, 0, 2, 1, 1);


        gridLayout_2->addWidget(widget_2, 0, 0, 1, 1);

        tableWidget = new QTableWidget(widget);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));

        gridLayout_2->addWidget(tableWidget, 1, 0, 1, 1);


        gridLayout_3->addWidget(widget, 0, 0, 1, 1);


        retranslateUi(borrow_login);

        QMetaObject::connectSlotsByName(borrow_login);
    } // setupUi

    void retranslateUi(QDialog *borrow_login)
    {
        borrow_login->setWindowTitle(QCoreApplication::translate("borrow_login", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("borrow_login", "\346\220\234\347\264\242", nullptr));
        pushButton_2->setText(QCoreApplication::translate("borrow_login", "\344\277\256\346\224\271\344\277\241\346\201\257", nullptr));
        pushButton->setText(QCoreApplication::translate("borrow_login", "\347\224\250\346\210\267\346\267\273\345\212\240", nullptr));
        pushButton_3->setText(QCoreApplication::translate("borrow_login", "\346\237\245\350\257\242", nullptr));
    } // retranslateUi

};

namespace Ui {
    class borrow_login: public Ui_borrow_login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STUDEN_MRG_H
