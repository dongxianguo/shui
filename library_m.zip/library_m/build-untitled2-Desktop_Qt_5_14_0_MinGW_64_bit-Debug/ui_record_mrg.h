/********************************************************************************
** Form generated from reading UI file 'record_mrg.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECORD_MRG_H
#define UI_RECORD_MRG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_record_mrg
{
public:
    QGridLayout *gridLayout;
    QWidget *widget;
    QGridLayout *gridLayout_4;
    QWidget *widget_3;
    QGridLayout *gridLayout_5;
    QPushButton *pushButton_8;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_7;
    QPushButton *pushButton_6;
    QLabel *label_3;
    QPushButton *pushButton;
    QTableView *tableView_3;
    QPushButton *pushButton_5;

    void setupUi(QDialog *record_mrg)
    {
        if (record_mrg->objectName().isEmpty())
            record_mrg->setObjectName(QString::fromUtf8("record_mrg"));
        record_mrg->resize(624, 499);
        gridLayout = new QGridLayout(record_mrg);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        widget = new QWidget(record_mrg);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout_4 = new QGridLayout(widget);
        gridLayout_4->setSpacing(0);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        widget_3 = new QWidget(widget);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        gridLayout_5 = new QGridLayout(widget_3);
        gridLayout_5->setSpacing(0);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        pushButton_8 = new QPushButton(widget_3);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));
        pushButton_8->setEnabled(true);

        gridLayout_5->addWidget(pushButton_8, 1, 6, 1, 1);

        lineEdit_3 = new QLineEdit(widget_3);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));

        gridLayout_5->addWidget(lineEdit_3, 0, 1, 3, 1);

        pushButton_7 = new QPushButton(widget_3);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));

        gridLayout_5->addWidget(pushButton_7, 1, 4, 1, 1);

        pushButton_6 = new QPushButton(widget_3);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));

        gridLayout_5->addWidget(pushButton_6, 1, 2, 1, 1);

        label_3 = new QLabel(widget_3);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_5->addWidget(label_3, 0, 0, 3, 1);

        pushButton = new QPushButton(widget_3);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout_5->addWidget(pushButton, 1, 3, 1, 1);


        gridLayout_4->addWidget(widget_3, 0, 0, 1, 1);

        tableView_3 = new QTableView(widget);
        tableView_3->setObjectName(QString::fromUtf8("tableView_3"));

        gridLayout_4->addWidget(tableView_3, 1, 0, 1, 1);

        pushButton_5 = new QPushButton(widget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        gridLayout_4->addWidget(pushButton_5, 2, 0, 1, 1);


        gridLayout->addWidget(widget, 0, 0, 1, 1);


        retranslateUi(record_mrg);

        QMetaObject::connectSlotsByName(record_mrg);
    } // setupUi

    void retranslateUi(QDialog *record_mrg)
    {
        record_mrg->setWindowTitle(QCoreApplication::translate("record_mrg", "Dialog", nullptr));
        pushButton_8->setText(QCoreApplication::translate("record_mrg", "\345\275\222\350\277\230\345\233\276\344\271\246", nullptr));
        pushButton_7->setText(QCoreApplication::translate("record_mrg", "\345\200\237\351\230\205\345\233\276\344\271\246", nullptr));
        pushButton_6->setText(QCoreApplication::translate("record_mrg", "\346\237\245\350\257\242", nullptr));
        label_3->setText(QCoreApplication::translate("record_mrg", "\346\220\234\347\264\242", nullptr));
        pushButton->setText(QCoreApplication::translate("record_mrg", "\346\237\245\350\257\242\345\200\237\351\230\205\351\207\217", nullptr));
        pushButton_5->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class record_mrg: public Ui_record_mrg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECORD_MRG_H
