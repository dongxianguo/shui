/********************************************************************************
** Form generated from reading UI file 'book_mrg.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BOOK_MRG_H
#define UI_BOOK_MRG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_book_mrg
{
public:
    QGridLayout *gridLayout;
    QWidget *widget;
    QGridLayout *gridLayout_3;
    QWidget *widget_2;
    QGridLayout *gridLayout_2;
    QLabel *label;
    QPushButton *select;
    QPushButton *add;
    QPushButton *remove;
    QPushButton *update;
    QLineEdit *lineEdit;
    QTableView *tableView;

    void setupUi(QDialog *book_mrg)
    {
        if (book_mrg->objectName().isEmpty())
            book_mrg->setObjectName(QString::fromUtf8("book_mrg"));
        book_mrg->resize(654, 542);
        gridLayout = new QGridLayout(book_mrg);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setHorizontalSpacing(9);
        gridLayout->setVerticalSpacing(7);
        gridLayout->setContentsMargins(0, 0, 9, 9);
        widget = new QWidget(book_mrg);
        widget->setObjectName(QString::fromUtf8("widget"));
        gridLayout_3 = new QGridLayout(widget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setHorizontalSpacing(9);
        gridLayout_3->setVerticalSpacing(7);
        gridLayout_3->setContentsMargins(11, 0, 9, 9);
        widget_2 = new QWidget(widget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        gridLayout_2 = new QGridLayout(widget_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setHorizontalSpacing(9);
        gridLayout_2->setVerticalSpacing(7);
        gridLayout_2->setContentsMargins(0, 0, 9, 9);
        label = new QLabel(widget_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_2->addWidget(label, 0, 0, 3, 1);

        select = new QPushButton(widget_2);
        select->setObjectName(QString::fromUtf8("select"));

        gridLayout_2->addWidget(select, 1, 6, 1, 1);

        add = new QPushButton(widget_2);
        add->setObjectName(QString::fromUtf8("add"));

        gridLayout_2->addWidget(add, 1, 2, 1, 1);

        remove = new QPushButton(widget_2);
        remove->setObjectName(QString::fromUtf8("remove"));

        gridLayout_2->addWidget(remove, 1, 4, 1, 1);

        update = new QPushButton(widget_2);
        update->setObjectName(QString::fromUtf8("update"));

        gridLayout_2->addWidget(update, 1, 5, 1, 1);

        lineEdit = new QLineEdit(widget_2);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        gridLayout_2->addWidget(lineEdit, 0, 1, 3, 1);


        gridLayout_3->addWidget(widget_2, 0, 0, 1, 1);

        tableView = new QTableView(widget);
        tableView->setObjectName(QString::fromUtf8("tableView"));

        gridLayout_3->addWidget(tableView, 1, 0, 1, 1);


        gridLayout->addWidget(widget, 0, 0, 1, 1);


        retranslateUi(book_mrg);

        QMetaObject::connectSlotsByName(book_mrg);
    } // setupUi

    void retranslateUi(QDialog *book_mrg)
    {
        book_mrg->setWindowTitle(QCoreApplication::translate("book_mrg", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("book_mrg", "\346\220\234\347\264\242", nullptr));
        select->setText(QCoreApplication::translate("book_mrg", "\346\237\245\350\257\242", nullptr));
        add->setText(QCoreApplication::translate("book_mrg", "\346\267\273\345\212\240", nullptr));
        remove->setText(QCoreApplication::translate("book_mrg", "\345\210\240\351\231\244", nullptr));
        update->setText(QCoreApplication::translate("book_mrg", "\344\277\256\346\224\271", nullptr));
    } // retranslateUi

};

namespace Ui {
    class book_mrg: public Ui_book_mrg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BOOK_MRG_H
