/********************************************************************************
** Form generated from reading UI file 're_login.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RE_LOGIN_H
#define UI_RE_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_re_login
{
public:
    QGridLayout *gridLayout_4;
    QWidget *widget_2;
    QGridLayout *gridLayout_2;
    QLabel *lg_title;
    QWidget *widget;
    QGridLayout *gridLayout;
    QLabel *lg_txt1;
    QLineEdit *lg_user;
    QLabel *lg_txt2;
    QLineEdit *lg_id;
    QLabel *lg_txt3;
    QLineEdit *lg_phone;
    QLabel *lg_txt4;
    QLineEdit *lg_password1;
    QLabel *lg_txt5;
    QLineEdit *lg_password2;
    QWidget *widget_3;
    QGridLayout *gridLayout_3;
    QPushButton *pushButton_2;
    QPushButton *pushButton;

    void setupUi(QDialog *re_login)
    {
        if (re_login->objectName().isEmpty())
            re_login->setObjectName(QString::fromUtf8("re_login"));
        re_login->resize(866, 649);
        re_login->setStyleSheet(QString::fromUtf8("QLabel#lg_title{font: 38px \"\351\273\221\344\275\223\";}\n"
"QLabel#lg_txt1,QLabel#lg_txt2,QLabel#lg_txt3,QLabel#lg_txt4,QLabel#lg_txt5{font: 18px \"\346\245\267\344\275\223\";}\n"
"QLineEdit{border-radius:4px;min-height:25px;border:1px solid gray;}\n"
"QPushButton{border-radius:4px;background:#409eff;color:white;font-size:14px;}\n"
"QDialog#re_login{background:white;}\n"
""));
        gridLayout_4 = new QGridLayout(re_login);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        widget_2 = new QWidget(re_login);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setMaximumSize(QSize(800, 150));
        gridLayout_2 = new QGridLayout(widget_2);
        gridLayout_2->setSpacing(0);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        lg_title = new QLabel(widget_2);
        lg_title->setObjectName(QString::fromUtf8("lg_title"));
        lg_title->setMaximumSize(QSize(500, 100));
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        lg_title->setFont(font);
        lg_title->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(lg_title, 0, 0, 1, 1);


        gridLayout_4->addWidget(widget_2, 0, 0, 1, 1);

        widget = new QWidget(re_login);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setMaximumSize(QSize(800, 400));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        lg_txt1 = new QLabel(widget);
        lg_txt1->setObjectName(QString::fromUtf8("lg_txt1"));
        lg_txt1->setMaximumSize(QSize(150, 30));
        lg_txt1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(lg_txt1, 0, 0, 1, 1);

        lg_user = new QLineEdit(widget);
        lg_user->setObjectName(QString::fromUtf8("lg_user"));
        lg_user->setMaximumSize(QSize(400, 30));

        gridLayout->addWidget(lg_user, 0, 1, 1, 1);

        lg_txt2 = new QLabel(widget);
        lg_txt2->setObjectName(QString::fromUtf8("lg_txt2"));
        lg_txt2->setMaximumSize(QSize(150, 30));
        lg_txt2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(lg_txt2, 1, 0, 1, 1);

        lg_id = new QLineEdit(widget);
        lg_id->setObjectName(QString::fromUtf8("lg_id"));
        lg_id->setMaximumSize(QSize(400, 30));

        gridLayout->addWidget(lg_id, 1, 1, 1, 1);

        lg_txt3 = new QLabel(widget);
        lg_txt3->setObjectName(QString::fromUtf8("lg_txt3"));
        lg_txt3->setMaximumSize(QSize(150, 30));
        lg_txt3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(lg_txt3, 2, 0, 1, 1);

        lg_phone = new QLineEdit(widget);
        lg_phone->setObjectName(QString::fromUtf8("lg_phone"));
        lg_phone->setMaximumSize(QSize(400, 30));

        gridLayout->addWidget(lg_phone, 2, 1, 1, 1);

        lg_txt4 = new QLabel(widget);
        lg_txt4->setObjectName(QString::fromUtf8("lg_txt4"));
        lg_txt4->setMaximumSize(QSize(150, 30));
        lg_txt4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(lg_txt4, 3, 0, 1, 1);

        lg_password1 = new QLineEdit(widget);
        lg_password1->setObjectName(QString::fromUtf8("lg_password1"));
        lg_password1->setMaximumSize(QSize(400, 30));

        gridLayout->addWidget(lg_password1, 3, 1, 1, 1);

        lg_txt5 = new QLabel(widget);
        lg_txt5->setObjectName(QString::fromUtf8("lg_txt5"));
        lg_txt5->setMaximumSize(QSize(150, 30));
        lg_txt5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(lg_txt5, 4, 0, 1, 1);

        lg_password2 = new QLineEdit(widget);
        lg_password2->setObjectName(QString::fromUtf8("lg_password2"));
        lg_password2->setMaximumSize(QSize(400, 30));

        gridLayout->addWidget(lg_password2, 4, 1, 1, 1);


        gridLayout_4->addWidget(widget, 1, 0, 1, 1);

        widget_3 = new QWidget(re_login);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        widget_3->setMaximumSize(QSize(800, 150));
        gridLayout_3 = new QGridLayout(widget_3);
        gridLayout_3->setSpacing(0);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton_2 = new QPushButton(widget_3);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMaximumSize(QSize(300, 50));

        gridLayout_3->addWidget(pushButton_2, 1, 0, 1, 1);

        pushButton = new QPushButton(widget_3);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMaximumSize(QSize(300, 50));

        gridLayout_3->addWidget(pushButton, 0, 0, 1, 1);


        gridLayout_4->addWidget(widget_3, 2, 0, 1, 1);


        retranslateUi(re_login);

        QMetaObject::connectSlotsByName(re_login);
    } // setupUi

    void retranslateUi(QDialog *re_login)
    {
        re_login->setWindowTitle(QCoreApplication::translate("re_login", "Dialog", nullptr));
        lg_title->setText(QCoreApplication::translate("re_login", "\346\263\250  \345\206\214", nullptr));
        lg_txt1->setText(QCoreApplication::translate("re_login", "\345\247\223\345\220\215\357\274\232", nullptr));
        lg_txt2->setText(QCoreApplication::translate("re_login", "\347\224\250\346\210\267\345\220\215\357\274\232", nullptr));
        lg_txt3->setText(QCoreApplication::translate("re_login", "\350\201\224\347\263\273\346\226\271\345\274\217\357\274\232", nullptr));
        lg_txt4->setText(QCoreApplication::translate("re_login", "\345\257\206\347\240\201\357\274\232", nullptr));
        lg_txt5->setText(QCoreApplication::translate("re_login", "\351\207\215\345\244\215\345\257\206\347\240\201\357\274\232", nullptr));
        pushButton_2->setText(QCoreApplication::translate("re_login", "\345\267\262\346\234\211\350\264\246\345\217\267\357\274\214\347\231\273\345\275\225", nullptr));
        pushButton->setText(QCoreApplication::translate("re_login", "\346\263\250\345\206\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class re_login: public Ui_re_login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RE_LOGIN_H
