/********************************************************************************
** Form generated from reading UI file 'count_marg.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_COUNT_MARG_H
#define UI_COUNT_MARG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_count_marg
{
public:
    QGridLayout *gridLayout;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QTableView *tableView;

    void setupUi(QDialog *count_marg)
    {
        if (count_marg->objectName().isEmpty())
            count_marg->setObjectName(QString::fromUtf8("count_marg"));
        count_marg->resize(684, 565);
        gridLayout = new QGridLayout(count_marg);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        widget = new QWidget(count_marg);
        widget->setObjectName(QString::fromUtf8("widget"));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        horizontalLayout->addWidget(lineEdit);


        gridLayout->addWidget(widget, 0, 0, 1, 1);

        tableView = new QTableView(count_marg);
        tableView->setObjectName(QString::fromUtf8("tableView"));

        gridLayout->addWidget(tableView, 1, 0, 1, 1);


        retranslateUi(count_marg);

        QMetaObject::connectSlotsByName(count_marg);
    } // setupUi

    void retranslateUi(QDialog *count_marg)
    {
        count_marg->setWindowTitle(QCoreApplication::translate("count_marg", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("count_marg", "\345\200\237\351\230\205\351\207\217\357\274\232", nullptr));
    } // retranslateUi

};

namespace Ui {
    class count_marg: public Ui_count_marg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_COUNT_MARG_H
