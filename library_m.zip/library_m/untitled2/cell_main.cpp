#include "cell_main.h"
#include "ui_cell_main.h"
#include<QPushButton>
#include<QMessageBox>
#include<QDebug>
cell_main::cell_main(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::cell_main)
    ,m_studentPage(nullptr)
    ,m_bookPage(nullptr)
    ,m_recordPage(nullptr)
    ,m_countPage(nullptr)
{
    ui->setupUi(this);
    initPage();
}

cell_main::~cell_main()
{
    delete ui;
}
void cell_main::initPage()
{
    m_studentPage=new borrow_login(this);
    m_bookPage=new book_mrg(this);
    m_recordPage=new record_mrg(this);
    m_countPage=new count_marg(this);
    ui->stackedWidget->addWidget(m_studentPage);
    ui->stackedWidget->addWidget(m_bookPage);
    ui->stackedWidget->addWidget(m_recordPage);
    ui->stackedWidget->addWidget(m_countPage);
    auto l=ui->tool->children();
    for(auto it:l){
        if(it->objectName().contains("btn")){
            connect(static_cast<QPushButton*>(it),&QPushButton::clicked,this,&cell_main::dealMeau);
        }
    }
}

void cell_main::dealMeau(){
    auto str= sender()->objectName();
    if("btn_user"==str){
        ui->stackedWidget->setCurrentIndex(0);
    }
    if("btn_book"==str){
        ui->stackedWidget->setCurrentIndex(1);
    }

    if("btn_brower"==str){
        ui->stackedWidget->setCurrentIndex(2);
    }

    if("btn_count"==str){
        ui->stackedWidget->setCurrentIndex(3);
    }

}



