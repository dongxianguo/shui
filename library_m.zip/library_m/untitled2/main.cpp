#include "cell_main.h"
#include "dig_login.h"
#include <QApplication>
#include<QSqlDatabase>
#include<QDebug>
#include<QSqlQuery>
#include <QSqlError>
#include "sqlite.h"
#include<QMessageBox>
#include <QSqlTableModel>   //用来显示数据库中数据表的数据，实现对数据的编辑、插入、删除等操作。实现数据的排序和过滤
#include <QTableView>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Dig_login login;
//    sqlite::getInstance()->init();
//    sqlite::getInstance()->login("isi","123");
   int re= login.exec();
   qDebug()<<re;
   if(re==1){//登录成功

       cell_main c;
       c.show();
        QMessageBox::information(NULL,"","登录成功");
       return a.exec();
   }
   else{//注册
       re_login r;
       r.show();
       int temp=r.exec();
       if(temp==1){
           login.exec();
           cell_main c;
           c.show();
           return a.exec();
       }

   }

    return a.exec();
}
