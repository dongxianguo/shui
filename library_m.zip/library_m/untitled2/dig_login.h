#ifndef DIG_LOGIN_H
#define DIG_LOGIN_H

#include <QDialog>
#include "re_login.h"
namespace Ui {
class Dig_login;
}

class Dig_login : public QDialog
{
    Q_OBJECT

public:
    explicit Dig_login(QWidget *parent = nullptr);
    static int is_root;
    ~Dig_login();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Dig_login *ui;
};

#endif // DIG_LOGIN_H
