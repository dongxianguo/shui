#ifndef CELL_MAIN_H
#define CELL_MAIN_H
#include "book_mrg.h"
#include "studen_mrg.h"
#include <QMainWindow>
#include "record_mrg.h"
#include "count_marg.h"
QT_BEGIN_NAMESPACE
namespace Ui { class cell_main; }
QT_END_NAMESPACE

class cell_main : public QMainWindow
{
    Q_OBJECT

public:
    cell_main(QWidget *parent = nullptr);
    void initPage();
    ~cell_main();

    void dealMeau();
private slots:

private:
    Ui::cell_main *ui;
    borrow_login *m_studentPage;
    book_mrg *m_bookPage;
    record_mrg *m_recordPage;
    count_marg  *m_countPage;
};
#endif // CELL_MAIN_H
