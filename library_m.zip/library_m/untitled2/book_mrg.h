#ifndef BOOK_MRG_H
#define BOOK_MRG_H
#include <QDialog>
#include "book_add.h"
#include<QStandardItemModel>
#include "dig_login.h"
namespace Ui {
class book_mrg;
}

class book_mrg : public QDialog
{
    Q_OBJECT

public:
    explicit book_mrg(QWidget *parent = nullptr);
    void  creatTable(QString id,QString name,QString author,QString press,QString type,QString ISBN,QString statue);
    ~book_mrg();


private slots:
    void on_add_clicked();

    void on_select_clicked();
    void on_remove_clicked();
    void on_update_clicked();
private:
    Ui::book_mrg *ui;
    QStandardItemModel m_model;

};

#endif // BOOK_MRG_H
