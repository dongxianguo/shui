#include "dig_login.h"
#include "ui_dig_login.h"
#include "sqlite.h"
#include "cell_main.h"
#include<QLineEdit>
#include<QMessageBox>
#include "book_mrg.h"
Dig_login::Dig_login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dig_login)
{
    ui->setupUi(this);

    ui->line_user->setPlaceholderText("請输入用户名");

       //密码输入提示
     ui->line_password->setPlaceholderText("请输入密码");

}

Dig_login::~Dig_login()
{
    delete ui;
}
int Dig_login::is_root=0;
void Dig_login::on_pushButton_clicked()
{
    sqlite::getInstance()->init();
    QSqlDatabase db;
    QSqlQuery q(db);
    QString user,password;
    user=ui->line_user->text();//获取用户名
    password=ui->line_password->text();//获取密码
    if(user==""){
        QMessageBox::warning(this,"","用户名不能为空！");
        setResult(0);

    }
    else if(password=="") {
        QMessageBox::warning(this,"","密码不能为空！");

    setResult(0);
    }
    else{

       QString select_sql=QString("select * from account where number='%1'").arg(user);
       q.exec(select_sql);
       q.next();
       if(q.value(1).toString()==""){
           QMessageBox::warning(NULL,"Error","用户不存在");
       }
       else{
           if(user.size()==6){
               is_root=1;
           }
           else is_root=0;
           if(q.value(2).toString()==password){

               setResult(1);
               hide();
           }
           else{
               QMessageBox::warning(NULL,"Error","密码错误");
           }
       }

    }

}

void Dig_login::on_pushButton_2_clicked()
{
    this->hide();
    setResult(2);

}
