#ifndef SQLITE_H
#define SQLITE_H

#include<QDebug>
#include<QSqlDatabase>
#include<QSqlQuery>
class sqlite
{
public:
    sqlite();
    ~sqlite();
    static sqlite *instance;
    static sqlite* getInstance(){
        if(nullptr==instance){
            instance=new sqlite();
        }
         return instance;
    }
    void init();
    //登录
    bool login(QString account,QString password);

    QVector<QString> getUsser(QString strCondition="");
    void test(){
        qDebug()<<"test";
    }
private:
    QSqlDatabase m_db;
};

#endif // SQLITE_H
