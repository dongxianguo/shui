#include "re_login.h"
#include "ui_re_login.h"
#include<QMessageBox>
#include "sqlite.h"
#include "book_mrg.h"
re_login::re_login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::re_login)
{
    ui->setupUi(this);
    ui->lg_user->setPlaceholderText("请输入姓名");
    ui->lg_id->setPlaceholderText("请输入用户名");
    ui->lg_phone->setPlaceholderText("请输入电话号码");
    ui->lg_password1->setPlaceholderText("请设置您的密码");
    ui->lg_password2->setPlaceholderText("请再次输入您的密码");
}

bool re_login::isLogin(QString number)
{
    sqlite::getInstance()->init();
    QSqlDatabase db;
    QSqlQuery q(db);
    QString s=QString("select * from account where number= '%1'").arg(number);
    q.exec(s);
    q.next();
    if(q.value(1).toString()==number){
        return true;
    }
    else{
        return false;
    }

}

re_login::~re_login()
{
    delete ui;
}

void re_login::on_pushButton_clicked()
{
    QString account,password1,password2,name,call;
    account=ui->lg_id->text();
    password1=ui->lg_password1->text();
    password2=ui->lg_password2->text();
    name=ui->lg_user->text();
    call=ui->lg_phone->text();
    int role=0;
    if(name==""){
         QMessageBox::warning(NULL,"Error","姓名不能为空");
    }
    if(account==""){
         QMessageBox::warning(NULL,"Error","用户名不能为空");
    }
    if(password1==""||password2==""){
         QMessageBox::warning(NULL,"Error","密码不能为空");
    }
    if(password1!=password2){
        QMessageBox::warning(NULL,"Error","输入的2次密码不同");
    }
    else{
        bool re=this->isLogin(account);
        qDebug()<<re;
        if(re){
             QMessageBox::warning(NULL,"Error","该账号已经注册");
        }
        else{
            if(account.size()==6){
                role=1;
            }
            sqlite::getInstance()->init();
            QSqlDatabase db;
            QSqlQuery q(db);
            QString s=QString("insert into account(number,password) values('%1', '%2')").arg(account).arg(password1);
            if(!q.exec(s)){
                QMessageBox::information(this,"","注册失败");
            }

            else {
                QString s=QString("insert into user(number,name,phone) values('%1', '%2','%3','%4')").arg(account).arg(name).arg(call).arg(role);
                qDebug()<<q.exec(s);
                QMessageBox::information(this,"","注册成功");
            }
        }
    }

}

void re_login::on_pushButton_2_clicked()
{
    hide();
    setResult(1);
}
