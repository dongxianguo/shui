#include "count_marg.h"
#include "ui_count_marg.h"

count_marg::count_marg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::count_marg)
{
    ui->setupUi(this);
}

count_marg::~count_marg()
{
    delete ui;
}
