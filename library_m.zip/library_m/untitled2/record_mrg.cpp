#include "record_mrg.h"
#include "ui_record_mrg.h"
#include <QMessageBox>
#include "sqlite.h"
record_mrg::record_mrg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::record_mrg)
{
    ui->setupUi(this);
    ui->lineEdit_3->setPlaceholderText("请输入查询的书名");

}

void record_mrg::creatTable(QString id, QString book_name, QString user_name, QString creat_time
                            , QString return_time, QString during_time, QString is_return)
{
    QList<QStandardItem*> items;
    items.append(new QStandardItem(id));
    items.append(new QStandardItem(book_name));
    items.append(new QStandardItem(user_name));
    items.append(new QStandardItem(creat_time));
    items.append(new QStandardItem(return_time));
    items.append(new QStandardItem(during_time));
    items.append(new QStandardItem(is_return));
    m_model.appendRow(items);
}

void record_mrg::creatTable1(QString id, QString book_name, QString user_name, QString creat_time, QString return_time, QString during_time, QString is_return, QString count)
{
    QList<QStandardItem*> items;
    items.append(new QStandardItem(id));
    items.append(new QStandardItem(book_name));
    items.append(new QStandardItem(user_name));
    items.append(new QStandardItem(creat_time));
    items.append(new QStandardItem(return_time));
    items.append(new QStandardItem(during_time));
    items.append(new QStandardItem(is_return));
    items.append(new QStandardItem(count));
    m_model.appendRow(items);
}

record_mrg::~record_mrg()
{
    delete ui;
}

void record_mrg::on_pushButton_6_clicked()//查询
{
    ui->tableView_3->setModel(&m_model);
    m_model.setHorizontalHeaderLabels(QStringList{"id","书名","借阅人姓名","借书开始时间","归还的时间","借书时长","是否归还"});
    QString str=ui->lineEdit_3->text();
    QSqlDatabase db;
    QSqlQuery q(db);
    if(str==""){
       bool re=q.exec("select* from record");
       if(re){
            m_model.removeRows(0,m_model.rowCount());
           while(q.next()){
               QString id,book_name,user_name,creat_time,return_time,during_time,is_return;
               id=q.value(0).toString();
               book_name=q.value(1).toString();
               user_name=q.value(2).toString();
               creat_time=q.value(3).toString();
               return_time=q.value(4).toString();
               during_time=q.value(5).toString();
               is_return=q.value(6).toString();
               this->creatTable(id,book_name,user_name,creat_time,return_time,during_time,is_return);
           }
            QMessageBox::information(NULL,"","查询成功");
       }
       else{
           QMessageBox::warning(NULL,"","查询失败");
       }
    }
    else{
        QString s=QString("select * from record where book_name='%1'").arg(str);
        m_model.removeRows(0,m_model.rowCount());
        if(q.exec(s)){
            m_model.removeRows(0,m_model.rowCount());
            int flag=0;
           while(q.next()){
               flag=1;
               QString id,book_name,user_name,creat_time,return_time,during_time,is_return;
               id=q.value(0).toString();
               book_name=q.value(1).toString();
               user_name=q.value(2).toString();
               creat_time=q.value(3).toString();
               return_time=q.value(4).toString();
               during_time=q.value(5).toString();
               is_return=q.value(6).toString();
               this->creatTable(id,book_name,user_name,creat_time,return_time,during_time,is_return);
           }
           if(flag==1)
           QMessageBox::information(NULL,"","查询成功");
           else
               QMessageBox::warning(NULL,"","未找到记录");
        }
        else{
             QMessageBox::warning(NULL,"","查询失败");
        }
    }
}

void record_mrg::on_pushButton_clicked()//查询借阅量
{
    ui->tableView_3->setModel(&m_model);
    m_model.setHorizontalHeaderLabels(QStringList{"id","书名","借阅人姓名","借书开始时间","归还的时间","借书时长","是否归还","借阅量"});
    QString str=ui->lineEdit_3->text();
    QSqlDatabase db;
    QSqlQuery q(db);
    if(str==""){
       bool re=q.exec("select id,book_name,user_name,creat_time,return_time,during_time,is_return,count(*) from record group by book_name");
       if(re){
            m_model.removeRows(0,m_model.rowCount());
           while(q.next()){
               QString id,book_name,user_name,creat_time,return_time,during_time,is_return,count;
               id=q.value(0).toString();
               book_name=q.value(1).toString();
               user_name=q.value(2).toString();
               creat_time=q.value(3).toString();
               return_time=q.value(4).toString();
               during_time=q.value(5).toString();
               is_return=q.value(6).toString();
               count=q.value(7).toString();
               this->creatTable1(id,book_name,user_name,creat_time,return_time,during_time,is_return,count);
           }
            QMessageBox::information(NULL,"","查询成功");
       }
       else{
           QMessageBox::warning(NULL,"","查询失败");
       }
    }
    else{
        QString s=QString("select id,book_name,user_name,creat_time,return_time,during_time,is_return,count(*) from record where book_name='%1' group by book_name").arg(str);
        m_model.removeRows(0,m_model.rowCount());
        if(q.exec(s)){
            m_model.removeRows(0,m_model.rowCount());
            int flag=0;
           while(q.next()){
               flag=1;
               QString id,book_name,user_name,creat_time,return_time,during_time,is_return,count;
               id=q.value(0).toString();
               book_name=q.value(1).toString();
               user_name=q.value(2).toString();
               creat_time=q.value(3).toString();
               return_time=q.value(4).toString();
               during_time=q.value(5).toString();
               is_return=q.value(6).toString();
               count=q.value(7).toString();
               this->creatTable1(id,book_name,user_name,creat_time,return_time,during_time,is_return,count);
           }
           if(flag==1)
           QMessageBox::information(NULL,"","查询成功");
           else
               QMessageBox::warning(NULL,"","未找到记录");
        }
        else{
             QMessageBox::warning(NULL,"","查询失败");
        }
    }

}
