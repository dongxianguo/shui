#ifndef COUNT_MARG_H
#define COUNT_MARG_H

#include <QDialog>

namespace Ui {
class count_marg;
}

class count_marg : public QDialog
{
    Q_OBJECT

public:
    explicit count_marg(QWidget *parent = nullptr);
    ~count_marg();

private:
    Ui::count_marg *ui;
};

#endif // COUNT_MARG_H
