#ifndef BOOK_LOGIN_H
#define BOOK_LOGIN_H

#include <QDialog>

namespace Ui {
class book_login;
}

class book_login : public QDialog
{
    Q_OBJECT

public:
    explicit book_login(QWidget *parent = nullptr);
    ~book_login();

private:
    Ui::book_login *ui;
};

#endif // BOOK_LOGIN_H
