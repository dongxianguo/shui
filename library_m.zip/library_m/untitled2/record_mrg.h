#ifndef RECORD_MRG_H
#define RECORD_MRG_H

#include <QDialog>
#include<QStandardItemModel>
namespace Ui {
class record_mrg;
}

class record_mrg : public QDialog
{
    Q_OBJECT

public:
    explicit record_mrg(QWidget *parent = nullptr);
    void  creatTable(QString id, QString book_name, QString user_name, QString creat_time
                     , QString return_time, QString during_time, QString is_return);
    void creatTable1(QString id, QString book_name, QString user_name, QString creat_time
                     , QString return_time, QString during_time, QString is_return,QString count);
    ~record_mrg();

private slots:
    void on_pushButton_6_clicked();

    void on_pushButton_clicked();

private:
    Ui::record_mrg *ui;
    QStandardItemModel m_model;
};

#endif // RECORD_MRG_H
