#include "sqlite.h"
#include<QSqlQuery>
#include<QCoreApplication>
sqlite* sqlite::instance=nullptr;
sqlite::sqlite()
{

}

sqlite::~sqlite()
{

}

void sqlite::init()
{
    QSqlDatabase DB;
   //分配数据库类型
    DB = QSqlDatabase::addDatabase("QSQLITE");
   //创建数据库表
    DB.setDatabaseName("library.db");   //会在编译的文件里面生成 ：如下图
    qDebug()<<DB.open();

}

bool sqlite::login(QString account, QString password)
{
    QSqlDatabase db;
    QSqlQuery q(db);
    QString s=QString(" select* from account  where number='%1'").arg(account);
    //q.exec("select * from account where number='%1'");
    qDebug()<<q.exec(s);
    q.next();
    if(q.value(1).toString()==account){
        qDebug()<<"cuowu";
    }
    while(q.next()){
        int id=q.value(0).toInt();
        QString number=q.value(1).toString();
        QString pass=q.value(2).toString();
        qDebug()<<id<<" "<<number<<pass;
    }
}
