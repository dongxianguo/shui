#ifndef READER_LOGIN_H
#define READER_LOGIN_H

#include <QDialog>

namespace Ui {
class reader_login;
}

class reader_login : public QDialog
{
    Q_OBJECT

public:
    explicit reader_login(QWidget *parent = nullptr);
    ~reader_login();

private:
    Ui::reader_login *ui;
};

#endif // READER_LOGIN_H
