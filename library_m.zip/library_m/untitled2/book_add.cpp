#include "book_add.h"
#include "ui_book_add.h"

book_login::book_login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::book_login)
{
    ui->setupUi(this);
}

book_login::~book_login()
{
    delete ui;
}
