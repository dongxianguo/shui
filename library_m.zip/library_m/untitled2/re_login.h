#ifndef RE_LOGIN_H
#define RE_LOGIN_H

#include <QDialog>

namespace Ui {
class re_login;
}

class re_login : public QDialog
{
    Q_OBJECT

public:
    explicit re_login(QWidget *parent = nullptr);
    bool isLogin(QString number);
    ~re_login();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::re_login *ui;
};

#endif // RE_LOGIN_H
