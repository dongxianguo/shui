#include "book_mrg.h"
#include "ui_book_mrg.h"
#include "book_add.h"
#include<QPushButton>
#include<QDebug>
#include<QSqlRecord>
#include "sqlite.h"
#include<QMessageBox>
#include "dig_login.h"
int flag1=0;
int flag2=0;
book_mrg::book_mrg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::book_mrg)
{
    ui->setupUi(this);
    ui->tableView->setModel(&m_model);
    m_model.setHorizontalHeaderLabels(QStringList{"id","书名","作者","出版社","类型","ISBN号","状态"});
    ui->tableView->viewport()->update();
    ui->lineEdit->setPlaceholderText("请输入需要查询的书名");
}
void book_mrg::creatTable(QString id, QString name, QString author, QString press, QString type, QString ISBN, QString statue)
{
    QList<QStandardItem*> items;
    items.append(new QStandardItem(id));
    items.append(new QStandardItem(name));
    items.append(new QStandardItem(author));
    items.append(new QStandardItem(press));
    items.append(new QStandardItem(type));
    items.append(new QStandardItem(ISBN));
    items.append(new QStandardItem(statue));
    m_model.appendRow(items);
}

book_mrg::~book_mrg()
{
    delete ui;
}

void book_mrg::on_add_clicked()//添加
{

    int re=Dig_login::is_root;
    if(re==0){
        QMessageBox::warning(NULL,"","无权限操作！");
        return;
    }
    if(flag2==0){
         m_model.removeRows(0,m_model.rowCount());
         flag2=1;
    }
     QList<QStandardItem*> items;
     m_model.appendRow(items);
     if(flag1==1){
        QModelIndexList list=ui->tableView->selectionModel()->selectedIndexes();
        if(list.size()%7!=0){
            QMessageBox::warning(NULL,"","请选中整行添加");
        }
        else{
            for(int i=1;i<list.size();i=i+7){
                QString name,author,press,ISBN,type;
                int statue;
                name=list[i].data().value<QString>();
                author=list[i+1].data().value<QString>();
                press=list[i+2].data().value<QString>();
                ISBN=list[i+3].data().value<QString>();
                type=list[i+4].data().value<QString>();
                statue=list[i+5].data().value<int>();
               QSqlDatabase db;
               QSqlQuery q(db);
               QString s=QString("insert into book(name,author,press,type,ISBN,statue) values('%1','%2','%3','%4','%5',0)").arg(name).arg(author).arg(press).arg(ISBN).arg(type);
               if(q.exec(s)){
                   QMessageBox::information(NULL,"","添加成功");
               }
               else{
                   QMessageBox::warning(NULL,"","添加失败");
               }
            }
     }
    }
     flag1=1;
}

void book_mrg::on_remove_clicked()//删除
{
    flag1=0;
    flag2=0;
    int re=Dig_login::is_root;
    if(re==0){
        QMessageBox::warning(NULL,"","无权限操作！");
        return;
    }
    QSqlDatabase db;
    QSqlQuery q(db);
    QMessageBox::StandardButton reply = QMessageBox::question(NULL, "Delete", "是否删除", QMessageBox::Yes | QMessageBox::No);
        if (reply == QMessageBox::No)
            return ;
        QItemSelectionModel *selections = ui->tableView->selectionModel();


        QModelIndexList selected = selections->selectedIndexes();//获取选中行的数据
        QMap<int, int> rowMap;
        foreach(QModelIndex index, selected)
        {
            rowMap.insert(index.row(), 0);
        }
        int rowToDel;
        QMapIterator<int, int> rowMapIterator(rowMap);
        rowMapIterator.toBack();
        int flag=0;
        for(int i=1;i<selected.size();i=i+7){
            QString name=selected[i].data().value<QString>();
            QString s=QString("delete from book where name='%1'").arg(name);
           if(!q.exec(s)){
               flag=1;
               break;
           }
        }
        if(flag==1){
            QMessageBox::warning(NULL,"","删除失败");
        }
        else{
            while (rowMapIterator.hasPrevious())
            {
                rowMapIterator.previous();
                rowToDel = rowMapIterator.key();
                m_model.removeRow(rowToDel);
            }
            QMessageBox::information(NULL,"","删除成功");
        }
}

void book_mrg::on_update_clicked()//修改
{
    flag1=0;
    flag2=0;
    int re=Dig_login::is_root;
    if(re==0){
        QMessageBox::warning(NULL,"","无权限操作！");
        return;
    }

}

void book_mrg::on_select_clicked()//查询
{
    flag1=0;
    flag2=0;
   QString str=ui->lineEdit->text();
   QSqlDatabase db;
   QSqlQuery q(db);
   if(str==""){
      bool re=q.exec("select* from book");
      if(re){

           m_model.removeRows(0,m_model.rowCount());
          while(q.next()){
              QString name,author,press,ISBN,type,id,statue;
              id=q.value(0).toString();
              name=q.value(1).toString();
              author=q.value(2).toString();
              press=q.value(3).toString();
              ISBN=q.value(4).toString();
              type=q.value(5).toString();
              statue=q.value(6).toString();
              this->creatTable(id,name,author,press,type,ISBN,statue);
          }
           QMessageBox::information(NULL,"","查询成功");
      }
      else{
          QMessageBox::warning(NULL,"","查询失败");
      }
   }
   else{
       QString s=QString("select * from book where name='%1'").arg(str);
       m_model.removeRows(0,m_model.rowCount());
       if(q.exec(s)){
           m_model.removeRows(0,m_model.rowCount());
           int flag=0;
          while(q.next()){
              flag=1;
              QString name,author,press,ISBN,type,id,statue;
              id=q.value(0).toString();
              name=q.value(1).toString();
              author=q.value(2).toString();
              press=q.value(3).toString();
              ISBN=q.value(4).toString();
              type=q.value(5).toString();
              statue=q.value(6).toString();
              this->creatTable(id,name,author,press,type,ISBN,statue);
          }
          if(flag==1)
          QMessageBox::information(NULL,"","查询成功");
          else
              QMessageBox::warning(NULL,"","未找到该图书");
       }
       else{
            QMessageBox::warning(NULL,"","查询失败");
       }
   }
    setResult(2);
}
