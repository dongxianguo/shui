#include "studen_mrg.h"
#include "ui_borrow_login.h"

borrow_login::borrow_login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::borrow_login)
{
    ui->setupUi(this);
//    ui->tableView->setModel(&m_model);
//    m_model.setHorizontalHeaderLabels(QStringList{"用户id","学号","姓名","电话"});
//    QList<QStandardItem*> items;
//    items.append(new QStandardItem("1"));
//    items.append(new QStandardItem("2022403023"));
//    items.append(new QStandardItem("lisi"));
//    items.append(new QStandardItem("15264078295"));
//   m_model.appendRow(items);
}

borrow_login::~borrow_login()
{
    delete ui;
}
