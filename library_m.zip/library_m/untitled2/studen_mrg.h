#ifndef BORROW_LOGIN_H
#define BORROW_LOGIN_H

#include <QDialog>
#include<QStandardItemModel>
namespace Ui {
class borrow_login;
}

class borrow_login : public QDialog
{
    Q_OBJECT

public:
    explicit borrow_login(QWidget *parent = nullptr);
    ~borrow_login();

private:
    Ui::borrow_login *ui;
    QStandardItemModel m_model;
};

#endif // BORROW_LOGIN_H
